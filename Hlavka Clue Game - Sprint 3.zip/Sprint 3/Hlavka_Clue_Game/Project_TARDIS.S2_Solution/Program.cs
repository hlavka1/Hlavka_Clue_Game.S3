﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlavka_Clue_Game
{
    class Program
    {
        static void Main(string[] args)
        {
            Controller _gameController = new Controller();
        }
    }
}
