﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlavka_Clue_Game
{
    public class Controller
    {
        #region FIELDS

        private bool _usingGame;

        //
        // declare all objects required for the game
        // Note - these field objects do not require properties since they
        //        are not accessed outside of the controller
        //
        private ConsoleView _gameConsoleView;
        private Player _gamePlayer;
        private Mansion _gameMansion;
        private int _murderWeaponID;

        #endregion

        #region PROPERTIES


        #endregion
        
        #region CONSTRUCTORS

        public Controller()
        {
            InitializeGame();

            //
            // instantiate a Player object
            //
            _gamePlayer = new Player();

            //
            // instantiate a ConsoleView object
            //
            _gameConsoleView = new ConsoleView(_gamePlayer, _gameMansion);

            //
            // begins running the application UI
            //
            ManageGameLoop();
        }

        #endregion
        
        #region METHODS

        /// <summary>
        /// initialize the game 
        /// </summary>
        private void InitializeGame()
        {
            _usingGame = true;
            _gameMansion = new Mansion();
            _gamePlayer = new Player();
            _gameConsoleView = new ConsoleView(_gamePlayer, _gameMansion);
            _murderWeaponID = SetMurderWeapon(); 

        }

        /// <summary>
        /// method to manage the application setup and control loop
        /// </summary>
        private void ManageGameLoop()
        {
            PlayerAction PlayerActionChoice;

            _gameConsoleView.DisplayWelcomeScreen();

            InitializeInvestigation();

            //
            // game loop
            //
            while (_usingGame)
            {

                UpdateGameStatus();
                //
                // get a menu choice from the ConsoleView object
                //
                PlayerActionChoice = _gameConsoleView.DisplayGetPlayerActionChoice();

                //
                // choose an action based on the user's menu choice
                //
                switch (PlayerActionChoice)
                {
                    case PlayerAction.None:
                        break;
                    case PlayerAction.LookAround:
                        _gameConsoleView.DisplayLookAround();
                        break;
                    case PlayerAction.LookAt:
                        _gameConsoleView.DisplayLookAt();
                        break;
                    case PlayerAction.PickUpItem:
                        int itemID;
                        itemID = _gameConsoleView.DisplayPickUpAndPutDownItem();

                        Item PickedUpItem = new Item();
                        PickedUpItem = _gameMansion.GetItemtByID(itemID);
                        _gamePlayer.PlayersItems.Add(PickedUpItem);
                        PickedUpItem.RoomID = 0;

                        break;
                    case PlayerAction.PickUpClue:
                        int clueID;
                        clueID = _gameConsoleView.DisplayPickUpAndPutDownClue();

                        Clue PickedUpClue = new Clue();
                        PickedUpClue = _gameMansion.GetClueByID(clueID);
                        _gamePlayer.PlayersEvidence.Add(PickedUpClue);
                        

                        if(PickedUpClue.GameObjectID == _murderWeaponID)
                        {
                         
                            UpdateGameStatus();
                        }
                        else
                        {
                            PickedUpClue.RoomID = 0;
                        }
                        break;

                    case PlayerAction.PutDownItem:
                        Console.WriteLine("Items currently in your inventory: ");
                        _gameConsoleView.DisplayPlayerItems();

                        itemID = _gameConsoleView.DisplayPickUpAndPutDownItem();

                        Item DroppedItem = new Item();
                        DroppedItem = _gameMansion.GetItemtByID(itemID);

                        _gamePlayer.PlayersItems.Remove(DroppedItem);

                        DroppedItem.RoomID = _gamePlayer.RoomID;
                        break;

                    case PlayerAction.PutDownClue:
                        Console.WriteLine("Treasures currently in your inventory: ");
                        _gameConsoleView.DisplayPlayerClue();
                        clueID = _gameConsoleView.DisplayPickUpAndPutDownClue();

                        Clue DroppedClue = new Clue();
                        DroppedClue = _gameMansion.GetClueByID(clueID);

                        _gamePlayer.PlayersEvidence.Remove(DroppedClue);

                        DroppedClue.RoomID = _gamePlayer.RoomID;
                        break;




                    ////int itemID;
                    //itemID = _gameConsoleView.DisplayItemToPutDown();

                    //Item ItemToPutDown = new Item();
                    //ItemToPutDown = _gameMansion.GetItemtByID(itemID);
                    //_gamePlayer.PlayersItems.Remove(ItemToPutDown);
                    //ItemToPutDown.RoomID = _gamePlayer.RoomID;


                    //case PlayerAction.PutDownClue:

                    //    break;
                    case PlayerAction.Travel:
                        _gamePlayer.RoomID = _gameConsoleView.DisplayGetPlayersNewDestination().RoomID;
                        break;
                    case PlayerAction.PlayerInfo:
                        _gameConsoleView.DisplayPlayerInfo();
                        break;
                    case PlayerAction.PlayerInventory:
                        _gameConsoleView.DisplayPlayerItems();
                        break;
                    case PlayerAction.PlayerClue:
                        _gameConsoleView.DisplayPlayerClue();
                        break;
                    case PlayerAction.ListROOMDestinations:
                        _gameConsoleView.DisplayListAllRoomDestinations();
                        break;
                    case PlayerAction.ListItems:
                        _gameConsoleView.DisplayListAllGameItems();
                        break;
                    case PlayerAction.ListClues:
                        _gameConsoleView.DisplayListAllGameClues();
                        break;
                    case PlayerAction.Exit:
                        _usingGame = false;
                        break;
                    default:
                        break;
                }
            }

            _gameConsoleView.DisplayExitPrompt();

            //
            // close the application
            //
            Environment.Exit(1);
        }

        private void UpdateGameStatus()
        {
            ConsoleUtil.DisplayMessage("Congratulations!  You have found the murder weapon!");
        }



        /// <summary>
        /// initialize the Player's starting investigation  parameters
        /// </summary>
        private void InitializeInvestigation()
        {
            _gameConsoleView.DisplayInvestigationSetupIntro();
            _gamePlayer.Name = _gameConsoleView.DisplayGetPlayersName();
            _gamePlayer.type = _gameConsoleView.DisplayGetplayersChoice();
            _gamePlayer.RoomID = _gameConsoleView.DisplayGetPlayersNewDestination().RoomID;

            // 
            // add initial items to the Player's inventory
            //
            AddItemToPlayersInventory(3);
            AddItemToPlayersClue(1);
        }

        /// <summary>
        /// add a game item to the Player's inventory
        /// </summary>
        /// <param name="itemID">game item ID</param>
        private void AddItemToPlayersInventory(int itemID)
        {
            Item item;

            item = _gameMansion.GetItemtByID(itemID);
            item.RoomID = 0;

            _gamePlayer.PlayersItems.Add(item);
        }

        /// <summary>
        /// add a game Clue to the Player's inventory
        /// </summary>
        /// <param name="itemID">game item ID</param>
        private void AddItemToPlayersClue(int itemID)
        {
            Clue item;

            item = _gameMansion.GetClueByID(itemID);
            item.RoomID = 0;

            _gamePlayer.PlayersEvidence.Add(item);
        }


        public int SetMurderWeapon()
        {
            Random myRandom = new Random();
            int randomClue = myRandom.Next(6);
            return randomClue;
        }


        public int SetKiller()
        {
            Random myRandom = new Random();
            int randomKiller = myRandom.Next(6) + 1;
            return randomKiller;
        }


        #endregion
    }
}
