﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlavka_Clue_Game
{
    /// <summary>
    /// Console class for the MVC pattern
    /// </summary>
    public class ConsoleView
    {
        #region FIELDS

        //
        // declare a Mansion and Player object for the ConsoleView object to use
        //
        Mansion _gameMansion;
        Player _gamePlayer;

        #endregion

        #region PROPERTIES

        #endregion

        #region CONSTRUCTORS

        /// <summary>
        /// default constructor to create the console view objects
        /// </summary>
        public ConsoleView(Player gamePlayer, Mansion gameMansion)
        {
            _gamePlayer = gamePlayer;
            _gameMansion = gameMansion;

            InitializeConsole();
        }

        #endregion

        #region METHODS

        /// <summary>
        /// initialize all console settings
        /// </summary>
        private void InitializeConsole()
        {
            ConsoleUtil.WindowTitle = "*** The Game Of Clue ***";
            ConsoleUtil.HeaderText = "*** The Game Of Clue ***";
        }

        /// <summary>
        /// display the Continue prompt
        /// </summary>
        public void DisplayContinuePrompt()
        {
            Console.CursorVisible = false;

            Console.WriteLine();

            ConsoleUtil.DisplayMessage("Press any key to continue.");
            ConsoleKeyInfo response = Console.ReadKey();

            Console.WriteLine();

            Console.CursorVisible = true;
        }

        /// <summary>
        /// display the Exit prompt on a clean screen
        /// </summary>
        public void DisplayExitPrompt()
        {
            ConsoleUtil.HeaderText = "Exit";
            ConsoleUtil.DisplayReset();

            Console.CursorVisible = false;

            Console.WriteLine();
            ConsoleUtil.DisplayMessage("Thank you for playing The Game Of Clue.I hope you found what you needed to catch a killer! Press any key to Exit.");

            Console.ReadKey();

            System.Environment.Exit(1);
        }

        /// <summary>
        /// display the welcome screen
        /// </summary>
        public void DisplayWelcomeScreen()
        {
            StringBuilder sb = new StringBuilder();

            ConsoleUtil.DisplayReset();

            ConsoleUtil.DisplayMessage("*** The Game Of Clue ***");
            ConsoleUtil.DisplayMessage("");
            ConsoleUtil.DisplayMessage("Written by Justina Hlavka");
            ConsoleUtil.DisplayMessage("Northwestern Michigan College");
            ConsoleUtil.DisplayMessage("CIT 195, Fall, 2016");
            Console.WriteLine();
            //
            // TODO update opening screen
            //

            sb.Clear();
            sb.AppendFormat("There has been a MURDER! ");
            sb.AppendFormat("You have traveled to Mr. Boddys' mansion to solve it.  ");
            sb.AppendFormat("Navigate your way through the mansion to find clues.  ");
            sb.AppendFormat("Once you find all the clues you will know who the murderer is!  ");
            sb.AppendFormat("GOOD LUCK! ");
            ConsoleUtil.DisplayMessage(sb.ToString());
            Console.WriteLine();

            sb.Clear();
            sb.AppendFormat("Your first task will be to set up who you would like to investigate the murder as.");
            ConsoleUtil.DisplayMessage(sb.ToString());

            DisplayContinuePrompt();
        }

        /// <summary>
        /// setup the new Player object
        /// </summary>
        public void DisplayInvestigationSetupIntro()
        {
            //
            // display header
            //
            ConsoleUtil.HeaderText = "Investigation Setup";
            ConsoleUtil.DisplayReset();

            //
            // display intro
            //
            ConsoleUtil.DisplayMessage("You will now be prompted to enter the starting parameters of your investigation.");
            DisplayContinuePrompt();
        }

        /// <summary>
        /// display a message confirming investigation setup
        /// </summary>
        public void DisplayInvestigationSetupConfirmation()
        {
            //
            // display header
            //
            ConsoleUtil.HeaderText = "Investigation Setup";
            ConsoleUtil.DisplayReset();
            ConsoleUtil.HeaderText = "Investigation Setup";
            ConsoleUtil.DisplayReset();

            //
            // display confirmation
            //
            ConsoleUtil.DisplayMessage("");
            ConsoleUtil.DisplayMessage("Your investigation setup is complete.");
            ConsoleUtil.DisplayMessage("");
            ConsoleUtil.DisplayMessage("To view your Room Player information use the Main Menu.");

            DisplayContinuePrompt();
        }

        /// <summary>
        /// get player's name
        /// </summary>
        /// <returns>name as a string</returns>
        public string DisplayGetPlayersName()
        {
            string PlayersName;

            //
            // display header
            //
            ConsoleUtil.HeaderText = "Player's Name";
            ConsoleUtil.DisplayReset();

            ConsoleUtil.DisplayPromptMessage("Enter your name: ");
            PlayersName = Console.ReadLine();

            ConsoleUtil.DisplayReset();
            ConsoleUtil.DisplayMessage($"You have indicated {PlayersName} as your name.");

            DisplayContinuePrompt();

            return PlayersName;
        }

        /// <summary>
        /// get and validate the player's type
        /// </summary>
        /// <returns>type as a PlayerType</returns>
        public Player.PlayerType DisplayGetplayersChoice()
        {
            bool validResponse = false;
            Player.PlayerType playersChoice = Player.PlayerType.None;

            while (!validResponse)
            {
                //
                // display header
                //
                ConsoleUtil.HeaderText = "Player's type";
                ConsoleUtil.DisplayReset();

                //
                // display all type types on a line
                //
                ConsoleUtil.DisplayMessage("Players");
                StringBuilder sb = new StringBuilder();
                foreach (Character.PlayerType PlayerType in Enum.GetValues(typeof(Character.PlayerType)))
                {
                    if (PlayerType != Character.PlayerType.None)
                    {
                        string playerTypeString = ConsoleUtil.ToLabelFormat(PlayerType.ToString());
                        ConsoleUtil.DisplayMessage(playerTypeString);
                    }

                }
                ConsoleUtil.DisplayMessage(sb.ToString());

                ConsoleUtil.DisplayPromptMessage("Enter the name of your desired player: ");

                //
                // validate user response for type
                //
                string userResponse = Console.ReadLine();
                string typeWithoutSpaces = ConsoleUtil.RemoveSpacesFormat(userResponse);

                if (Enum.TryParse<Character.PlayerType>(typeWithoutSpaces, out playersChoice))
                {
                    validResponse = true;
                    ConsoleUtil.DisplayReset();
                    ConsoleUtil.DisplayMessage("You have indicated " + userResponse + " as your desired player.");
                }
                else
                {
                    ConsoleUtil.DisplayMessage("You must limit your type to the list above.");
                    ConsoleUtil.DisplayMessage("Please reenter your type.");
                }

                DisplayContinuePrompt();
            }

            return playersChoice;
        }

        /// <summary>
        /// get and validate the player's Room destination
        /// </summary>
        /// <returns>room </returns>
        public Room DisplayGetPlayersNewDestination()
        {
            bool validResponse = false;
            int locationID;
            Room nextRoom = new Room();

            while (!validResponse)
            {
                //
                // display header
                //
                ConsoleUtil.HeaderText = "Room Destination";
                ConsoleUtil.DisplayReset();

                //
                // display a table of room s
                //
                DisplayRoomDestinationsTable();

                //
                // get and validate user's response for a room 
                //
                ConsoleUtil.DisplayPromptMessage("Choose the Room destination by entering the ID: ");

                //
                // user's response is an integer
                //
                if (int.TryParse(Console.ReadLine(), out locationID))
                {
                    ConsoleUtil.DisplayMessage("");

                    try
                    {
                        nextRoom = _gameMansion.GetRoomByID(locationID);

                        ConsoleUtil.DisplayReset();
                        ConsoleUtil.DisplayMessage($"You have indicated {nextRoom.Name} as your Room destination.");
                        ConsoleUtil.DisplayMessage("");

                        if (nextRoom.Accessable == true)
                        {
                            validResponse = true;
                            ConsoleUtil.DisplayMessage("You will walk down the corridor to the desired room.");
                        }
                        else
                        {
                            ConsoleUtil.DisplayMessage("It appears that room is locked!  Please look for a key and come back later.");
                            ConsoleUtil.DisplayMessage("Please make another choice.");
                        }
                    }
                    //
                    // user's response was not in the correct range
                    //
                    catch (ArgumentOutOfRangeException ex)
                    {
                        ConsoleUtil.DisplayMessage("It appears you entered an invalid location ID. that room does not exist.  Maybe Mr. Boddy will add another wing to the mansion one day.");
                        ConsoleUtil.DisplayMessage(ex.Message);
                        ConsoleUtil.DisplayMessage("Please try again.");
                    }
                }
                //
                // user's response was not an integer
                //
                else
                {
                    ConsoleUtil.DisplayMessage("It appears you did not enter a number for the room ID.");
                    ConsoleUtil.DisplayMessage("Please try again.");
                }

                DisplayContinuePrompt();
            }

            return nextRoom;
        }

        /// <summary>
        /// generate a table of room  names and ids
        /// </summary>
        public void DisplayRoomDestinationsTable()
        {
            int locationNumber = 1;
            //
            // table headings
            //
            ConsoleUtil.DisplayMessage("ID".PadRight(10) + "Name".PadRight(20));
            ConsoleUtil.DisplayMessage("---".PadRight(10) + "-------------".PadRight(20));

            //
            // location name and id
            //
            foreach (Room location in _gameMansion.Rooms)
            {
                ConsoleUtil.DisplayMessage(location.RoomID.ToString().PadRight(10) + location.Name.PadRight(20));
                locationNumber++;
            }
        }

        /// <summary>
        /// generate a table of item names and ids
        /// </summary>
        public void DisplayItemTable(List<Item> items)
        {
            //
            // table headings
            //
            ConsoleUtil.DisplayMessage("ID".PadRight(10) + "Name".PadRight(20));
            ConsoleUtil.DisplayMessage("---".PadRight(10) + "-------------".PadRight(20));

            //
            // item name and id
            //
            foreach (Item item in items)
            {
                ConsoleUtil.DisplayMessage(item.GameObjectID.ToString().PadRight(10) + item.Name.PadRight(20));
            }
        }

        /// <summary>
        /// generate a table of Clue names and ids
        /// </summary>
        public void DisplayClueTable(List<Clue> Clues)
        {
            //
            // table headings
            //
            ConsoleUtil.DisplayMessage("ID".PadRight(10) + "Name".PadRight(20));
            ConsoleUtil.DisplayMessage("---".PadRight(10) + "-------------".PadRight(20));

            //
            // Clue name and id
            //
            foreach (Clue Clue in Clues)
            {
                ConsoleUtil.DisplayMessage(Clue.GameObjectID.ToString().PadRight(10) + Clue.Name.PadRight(20));
            }
        }

        /// <summary>
        /// generate a table of Clue names and ids
        /// </summary>
        public void DisplaySexyFrenchMaidsTable(List<SexyFrenchMaids> SexyFrenchMaids)
        {
            //
            // table headings
            //
            ConsoleUtil.DisplayMessage("ID".PadRight(10) + "Name".PadRight(20));
            ConsoleUtil.DisplayMessage("---".PadRight(10) + "-------------".PadRight(20));

            //
            // Clue name and id
            //
            foreach (SexyFrenchMaids SexyFrenchMaid in SexyFrenchMaids)
            {
                ConsoleUtil.DisplayMessage(SexyFrenchMaid.GameObjectID.ToString().PadRight(10) + SexyFrenchMaid.Name.PadRight(20));
            }
        }

        /// <summary>
        /// get the action choice from the user
        /// </summary>
        public PlayerAction DisplayGetPlayerActionChoice()
        {
            PlayerAction PlayerActionChoice = PlayerAction.None;
            bool usingMenu = true;

            while (usingMenu)
            {
                //
                // set up display area
                //
                ConsoleUtil.HeaderText = "Player Action Choice";
                ConsoleUtil.DisplayReset();
                Console.CursorVisible = false;

                //
                // display the menu
                //
                ConsoleUtil.DisplayMessage("What would you like to do (Type Letter).");
                Console.WriteLine();
                Console.WriteLine(
                    "\t" + "**************************" + Environment.NewLine +
                    "\t" + "Player Actions" + Environment.NewLine +
                    "\t" + "**************************" + Environment.NewLine +
                    "\t" + "A. Look Around" + Environment.NewLine +
                    "\t" + "B. Look At" + Environment.NewLine +
                    "\t" + "C. Pick Up Item" + Environment.NewLine +
                    "\t" + "D. Pick Up Clue" + Environment.NewLine +
                    "\t" + "E. Put Down Item" + Environment.NewLine +
                    "\t" + "F. Put Down Clue" + Environment.NewLine +
                    "\t" + "G. Travel" + Environment.NewLine +
                    "\t" + Environment.NewLine +
                    "\t" + "**************************" + Environment.NewLine +
                    "\t" + "Player Information" + Environment.NewLine +
                    "\t" + "**************************" + Environment.NewLine +
                    "\t" + "H. Display General Player Info" + Environment.NewLine +
                    "\t" + "I. Display Player Inventory" + Environment.NewLine +
                    "\t" + "J. Display Player Clue" + Environment.NewLine +
                    "\t" + Environment.NewLine +
                    "\t" + "**************************" + Environment.NewLine +
                    "\t" + "Game Information" + Environment.NewLine +
                    "\t" + "**************************" + Environment.NewLine +
                    "\t" + "K. Display All Room Destinations" + Environment.NewLine +
                    "\t" + "L. Display All Game Items" + Environment.NewLine +
                    "\t" + "M. Display All Game Clues" + Environment.NewLine +
                    "\t" + Environment.NewLine +
                    "\t" + "**************************" + Environment.NewLine +
                    "\t" + "Q. Quit" + Environment.NewLine);

                //
                // get and process the user's response
                // note: ReadKey argument set to "true" disables the echoing of the key press
                //
                ConsoleKeyInfo userResponse = Console.ReadKey(true);
                switch (userResponse.KeyChar)
                {
                    case 'A':
                    case 'a':
                        PlayerActionChoice = PlayerAction.LookAround;
                        usingMenu = false;
                        break;
                    case 'B':
                    case 'b':
                        PlayerActionChoice = PlayerAction.LookAt;
                        usingMenu = false;
                        break;
                    case 'C':
                    case 'c':
                        PlayerActionChoice = PlayerAction.PickUpItem;
                        usingMenu = false;
                        break;
                    case 'D':
                    case 'd':
                        PlayerActionChoice = PlayerAction.PickUpClue;
                        usingMenu = false;
                        break;
                    case 'E':
                    case 'e':
                        PlayerActionChoice = PlayerAction.PutDownItem;
                        usingMenu = false;
                        break;
                    case 'F':
                    case 'f':
                        PlayerActionChoice = PlayerAction.PutDownClue;
                        usingMenu = false;
                        break;
                    case 'G':
                    case 'g':
                        PlayerActionChoice = PlayerAction.Travel;
                        usingMenu = false;
                        break;
                    case 'H':
                    case 'h':
                        PlayerActionChoice = PlayerAction.PlayerInfo;
                        usingMenu = false;
                        break;
                    case 'I':
                    case 'i':
                        PlayerActionChoice = PlayerAction.PlayerInventory;
                        usingMenu = false;
                        break;
                    case 'J':
                    case 'j':
                        PlayerActionChoice = PlayerAction.PlayerClue;
                        usingMenu = false;
                        break;
                    case 'K':
                    case 'k':
                        PlayerActionChoice = PlayerAction.ListROOMDestinations;
                        usingMenu = false;
                        break;
                    case 'L':
                    case 'l':
                        PlayerActionChoice = PlayerAction.ListItems;
                        usingMenu = false;
                        break;
                    case 'M':
                    case 'm':
                        PlayerActionChoice = PlayerAction.ListClues;
                        usingMenu = false;
                        break;
                    case 'Q':
                    case 'q':
                        PlayerActionChoice = PlayerAction.Exit;
                        usingMenu = false;
                        break;
                    default:
                        Console.WriteLine(
                            "It appears you have selected an incorrect choice." + Environment.NewLine +
                            "Press any key to continue or the ESC key to quit the application.");

                        userResponse = Console.ReadKey(true);
                        if (userResponse.Key == ConsoleKey.Escape)
                        {
                            usingMenu = false;
                        }
                        break;
                }
            }
            Console.CursorVisible = true;

            return PlayerActionChoice;
        }

        /// <summary>
        /// display information about the current room 
        /// </summary>
        public void DisplayLookAround()
        {
            ConsoleUtil.HeaderText = "Current room  Info";
            ConsoleUtil.DisplayReset();

            ConsoleUtil.DisplayMessage(_gameMansion.GetRoomByID(_gamePlayer.RoomID).Description);

            ConsoleUtil.DisplayMessage("");
            ConsoleUtil.DisplayMessage("Items in current location.");
            foreach (Item item in _gameMansion.GetItemsByRoomID(_gamePlayer.RoomID))
            {
                ConsoleUtil.DisplayMessage(item.Name + " - " + item.Description);
            }

            ConsoleUtil.DisplayMessage("");
            ConsoleUtil.DisplayMessage("Clues in current location.");
            foreach (Clue Clue in _gameMansion.GetCluesByRoomID(_gamePlayer.RoomID))
            {
                ConsoleUtil.DisplayMessage(Clue.Name + " - " + Clue.Description);
            }

            ConsoleUtil.DisplayMessage("");
            ConsoleUtil.DisplayMessage("Sexy French Maids in current location");
            foreach (SexyFrenchMaids SexyFrenchMaids in _gameMansion.GetSexyFrenchMaidsByRoomID(_gamePlayer.RoomID))
            {
                ConsoleUtil.DisplayMessage(SexyFrenchMaids.Name + " - " + SexyFrenchMaids.Description);
            }

            DisplayContinuePrompt();
        }

        /// <summary>
        /// display information about items and Clues in the current room 
        /// </summary>
        public void DisplayLookAt()
        {
            int currentrmidID = _gamePlayer.RoomID;
            List<Item> itemsInrmid = new List<Item>();
            List<Clue> CluesInrmid = new List<Clue>();
            List<SexyFrenchMaids> sexyFrenchMaidsInrmid = new List<SexyFrenchMaids>();
            Item itemToLookAt = new Item();
            Clue ClueToLookAt = new Clue();

            sexyFrenchMaidsInrmid = _gameMansion.GetSexyFrenchMaidsByRoomID(currentrmidID);
            CluesInrmid = _gameMansion.GetCluesByRoomID(currentrmidID);
            itemsInrmid = _gameMansion.GetItemsByRoomID(currentrmidID);

            ConsoleUtil.HeaderText = "Look at a Game Items in Current Location";
            ConsoleUtil.DisplayReset();

            ConsoleUtil.DisplayMessage(_gameMansion.GetRoomByID(currentrmidID).Name);

            if (itemsInrmid != null)
            {
                ConsoleUtil.DisplayMessage("");
                ConsoleUtil.DisplayMessage("Items in current location.");
                DisplayItemTable(itemsInrmid);

                ConsoleUtil.DisplayPromptMessage(
                    "Enter the item number to view or press the Enter key to move on. "
                    ); // TODO code in validation
                int itemIDChoice;

                if (int.TryParse(Console.ReadLine(), out itemIDChoice))
                {
                    itemToLookAt = _gameMansion.GetItemtByID(itemIDChoice);
                    ConsoleUtil.DisplayMessage(itemToLookAt.Description);

                    DisplayContinuePrompt();
                }
            }

            if (CluesInrmid != null)
            {
                ConsoleUtil.DisplayMessage("");
                ConsoleUtil.DisplayMessage("Clues in current location.");
                DisplayClueTable(CluesInrmid);

                ConsoleUtil.DisplayPromptMessage(
                    "Enter the Clue number to view or press the Enter key to move on. "
                    ); // TODO code in validation
                int ClueIDChoice;

                if (int.TryParse(Console.ReadLine(), out ClueIDChoice))
                {
                    ClueToLookAt = _gameMansion.GetClueByID(ClueIDChoice);
                    ConsoleUtil.DisplayMessage(ClueToLookAt.Description);

                    DisplayContinuePrompt();
                }
            }

            if (sexyFrenchMaidsInrmid != null)
            {
                ConsoleUtil.DisplayMessage("");
                ConsoleUtil.DisplayMessage("Sexy French Maids in current location.");
                DisplaySexyFrenchMaidsTable(sexyFrenchMaidsInrmid);

                ConsoleUtil.DisplayPromptMessage(
                    "Enter the Sexy French Maid number to view or press the Enter key to move on. "
                    ); // TODO code in validation
                int SexyFrenchMaidIDChoice;

                if (int.TryParse(Console.ReadLine(), out SexyFrenchMaidIDChoice))
                {
                    ClueToLookAt = _gameMansion.GetClueByID(SexyFrenchMaidIDChoice);
                    ConsoleUtil.DisplayMessage(ClueToLookAt.Description);

                    DisplayContinuePrompt();
                }
            }
        }

        /// <summary>
        /// display a list of all Room destinations
        /// <summary>
        public void DisplayListAllRoomDestinations()
        {
            ConsoleUtil.HeaderText = "rooms";
            ConsoleUtil.DisplayReset();

            foreach (Room location in _gameMansion.Rooms)
            {
                ConsoleUtil.DisplayMessage("ID: " + location.RoomID);
                ConsoleUtil.DisplayMessage("Name: " + location.Name);
                ConsoleUtil.DisplayMessage("Description: " + location.Description);
                ConsoleUtil.DisplayMessage("Accessible: " + location.Accessable);
                ConsoleUtil.DisplayMessage("");
            }

            DisplayContinuePrompt();
        }

        /// <summary>
        /// display a list of all game items
        /// <summary>
        public void DisplayListAllGameItems()
        {
            ConsoleUtil.HeaderText = "Game Items";
            ConsoleUtil.DisplayReset();

            foreach (Item item in _gameMansion.Items)
            {
                ConsoleUtil.DisplayMessage("ID: " + item.GameObjectID);
                ConsoleUtil.DisplayMessage("Name: " + item.Name);
                ConsoleUtil.DisplayMessage("Description: " + item.Description);

                //
                // all Clue in the Player's inventory have a RoomID of 0
                //
                if (item.RoomID != 0)
                {
                    ConsoleUtil.DisplayMessage("Location: " + _gameMansion.GetRoomByID(item.RoomID).Name);
                }
                else
                {
                    ConsoleUtil.DisplayMessage("Location: Player's Inventory");
                }


                ConsoleUtil.DisplayMessage("Value: " + item.Value);
                ConsoleUtil.DisplayMessage("Can Add to Inventory: " + item.CanAddToInventory.ToString().ToUpper());
                ConsoleUtil.DisplayMessage("");
            }

            DisplayContinuePrompt();
        }

        /// <summary>
        /// display a list of all game Clues
        /// <summary>
        public void DisplayListAllGameClues()
        {
            ConsoleUtil.HeaderText = "Game Clues";
            ConsoleUtil.DisplayReset();

            foreach (Clue Clue in _gameMansion.Clues)
            {
                ConsoleUtil.DisplayMessage("ID: " + Clue.GameObjectID);
                ConsoleUtil.DisplayMessage("Name: " + Clue.Name);
                ConsoleUtil.DisplayMessage("Description: " + Clue.Description);

                //
                // all Clue in the Player's inventory have a RoomID of 0
                //
                if (Clue.RoomID != 0)
                {
                    ConsoleUtil.DisplayMessage("Location: " + _gameMansion.GetRoomByID(Clue.RoomID).Name);
                }
                else
                {
                    ConsoleUtil.DisplayMessage("Location: Player's Inventory");
                }

                ConsoleUtil.DisplayMessage("Value: " + Clue.Value);
                ConsoleUtil.DisplayMessage("Can Add to Inventory: " + Clue.CanAddToInventory.ToString().ToUpper());
                ConsoleUtil.DisplayMessage("");
            }

            DisplayContinuePrompt();
        }

        /// <summary>
        /// display the current Player information
        /// </summary>
        public void DisplayPlayerInfo()
        {
            ConsoleUtil.HeaderText = "Player Info";
            ConsoleUtil.DisplayReset();

            ConsoleUtil.DisplayMessage($"Player's Name: {_gamePlayer.Name}");
            ConsoleUtil.DisplayMessage("");
            ConsoleUtil.DisplayMessage($"Player's type: {_gamePlayer.type}");
            ConsoleUtil.DisplayMessage("");
            string RoomName = _gameMansion.GetRoomByID(_gamePlayer.RoomID).Name;
            ConsoleUtil.DisplayMessage($"Player's Current Location: {RoomName}");

            DisplayContinuePrompt();
        }

        /// <summary>
        /// display the current Player inventory
        /// </summary>
        public void DisplayPlayerItems()
        {
            ConsoleUtil.HeaderText = "Player Inventory";
            ConsoleUtil.DisplayReset();

            ConsoleUtil.DisplayMessage("Player Items");
            ConsoleUtil.DisplayMessage("");

            foreach (Item item in _gamePlayer.PlayersItems)
            {
                ConsoleUtil.DisplayMessage("ID: " + item.GameObjectID);
                ConsoleUtil.DisplayMessage("Name: " + item.Name);
                ConsoleUtil.DisplayMessage("Description: " + item.Description);
                ConsoleUtil.DisplayMessage("");
            }

            DisplayContinuePrompt();
        }

        /// <summary>
        /// display the current Player's Clue
        /// </summary>
        public void DisplayPlayerClue()
        {
            ConsoleUtil.HeaderText = "Player Inventory";
            ConsoleUtil.DisplayReset();

            ConsoleUtil.DisplayMessage("");
            ConsoleUtil.DisplayMessage("Player Clue");
            ConsoleUtil.DisplayMessage("");

            foreach (Clue Clue in _gamePlayer.PlayersEvidence)
            {
                ConsoleUtil.DisplayMessage("ID: " + Clue.GameObjectID);
                ConsoleUtil.DisplayMessage("Name: " + Clue.Name);
                ConsoleUtil.DisplayMessage("Description: " + Clue.Description);
                ConsoleUtil.DisplayMessage("");
            }

            DisplayContinuePrompt();
        }

        /// <summary>
        /// get the id of an item to add to inventory
        /// </summary>
        /// <returns>id of desired item</returns>
        /// 

        public int DisplayPickUpAndPutDownItem()
        {
            ConsoleUtil.HeaderText = "Pick Up or Drop Item";
            ConsoleUtil.DisplayReset();

            ConsoleUtil.DisplayMessage("");
            ConsoleUtil.DisplayMessage("Items: ");
            ConsoleUtil.DisplayMessage("");

            int itemID = 0;

            int locationID;
            locationID = _gamePlayer.RoomID;

            foreach (Item item in _gameMansion.Items)
            {
                if (item.RoomID == locationID)
                {
                    Console.WriteLine(item.GameObjectID);
                    Console.WriteLine(item.Name);
                    Console.WriteLine();
                }
            }
            Console.WriteLine("Enter Item Number: ");
            itemID = int.Parse(Console.ReadLine());

            DisplayContinuePrompt();
            return itemID;
        }



        public int DisplayPickUpAndPutDownClue()
        {
            ConsoleUtil.HeaderText = "Pick Up or Drop Clue";
            ConsoleUtil.DisplayReset();

            ConsoleUtil.DisplayMessage("");
            ConsoleUtil.DisplayMessage("Clues: ");
            ConsoleUtil.DisplayMessage("");

            int clueID = 0;

            int locationID;
            locationID = _gamePlayer.RoomID;

            foreach (Clue clue in _gameMansion.Clues)
            {
                if (clue.RoomID == locationID)
                {
                    Console.WriteLine(clue.GameObjectID);
                    Console.WriteLine(clue.Name);
                    Console.WriteLine();
                }
            }
            Console.WriteLine("Enter Clue Number: ");

            Console.WriteLine();

            clueID = int.Parse(Console.ReadLine());

            DisplayContinuePrompt();
            return clueID;
        }
        //public int DisplayPickUpItem()
        //{
        //    ConsoleUtil.HeaderText = "Pick Up Item";
        //    ConsoleUtil.DisplayReset();

        //    int itemID = 0;

        //    int locationID;
        //    locationID = _gamePlayer.RoomID;

        //    List<Item> itemsInCurrentLocation = new List<Item>();
        //    itemsInCurrentLocation = _gameMansion.GetItemsByRoomID(locationID);

        //    ConsoleUtil.DisplayMessage("");
        //    ConsoleUtil.DisplayMessage("Items in current room");
        //    ConsoleUtil.DisplayMessage("");

        //    DisplayItemTable(itemsInCurrentLocation);

        //    ConsoleUtil.DisplayPromptMessage("Enter Item Number:");

        //    itemID = int.Parse(Console.ReadLine()); // TODO validate ID

        //    DisplayContinuePrompt();

        //    return itemID;
        //}

        //public int DisplayPickUpClue()
        //{
        //    ConsoleUtil.HeaderText = "Pick Up Clue";
        //    ConsoleUtil.DisplayReset();

        //    int clueID = 0;

        //    int locationID;
        //    locationID = _gamePlayer.RoomID;

        //    List<Clue> cluesInCurrentLocation = new List<Clue>();
        //    cluesInCurrentLocation = _gameMansion.GetCluesByRoomID(locationID);

        //    ConsoleUtil.DisplayMessage("");
        //    ConsoleUtil.DisplayMessage("Clues in current Location");
        //    ConsoleUtil.DisplayMessage("");

        //    DisplayClueTable(cluesInCurrentLocation);

        //    ConsoleUtil.DisplayPromptMessage("Enter Clue Number:");
        //    clueID = int.Parse(Console.ReadLine()); // TODO validate ID

        //    DisplayContinuePrompt();

        //    return clueID;
        //}


        //public int DisplayItemToPutDown()
        //{
        //    ConsoleUtil.HeaderText = "Put Down Item";
        //    ConsoleUtil.DisplayReset();

        //    int itemID = 0;

        //    int locationID;
        //    locationID = _gamePlayer.RoomID;

        //    List<Item> itemsInCurrentLocation = new List<Item>();
        //    itemsInCurrentLocation = _gameMansion.GetItemsByRoomID(locationID);

        //    ConsoleUtil.DisplayMessage("");
        //    ConsoleUtil.DisplayMessage("Items in current room");
        //    ConsoleUtil.DisplayMessage("");

        //    DisplayItemTable(itemsInCurrentLocation);

        //    ConsoleUtil.DisplayPromptMessage("Enter Item Number:");

        //    itemID = int.Parse(Console.ReadLine()); // TODO validate ID

        //    DisplayContinuePrompt();

        //    return itemID;
        //  }
        #endregion
    }
}
