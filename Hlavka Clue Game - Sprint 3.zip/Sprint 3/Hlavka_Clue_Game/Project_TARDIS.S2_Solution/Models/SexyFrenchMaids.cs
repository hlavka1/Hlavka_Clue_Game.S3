﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlavka_Clue_Game
{
    public class SexyFrenchMaids : Character

    {
        #region FIELDS

        bool HasMessage;

        string Message;


        private List<Item> _maidsItems;
        private List<Clue> maidsEvidence;

        #endregion

        public List<Item> MaidsItems
        {
            get { return _maidsItems; }
            set { _maidsItems = value; }
        }

        public List<Clue> MaidsEvidence
        {
            get { return maidsEvidence; }
            set {maidsEvidence = value; }
        }

        public int Value { get; internal set; }
        public int GameObjectID { get; internal set; }
        public string Description { get; internal set; }
        public bool HasValue { get; internal set; }
        public bool CanAddToInventory { get; internal set; }

        #region PROPERTIES



        #endregion


        #region CONSTRUCTORS

        public SexyFrenchMaids()
        {
            _maidsItems = new List<Item>();
            maidsEvidence = new List<Clue>();
        }

        public SexyFrenchMaids(string name, PlayerType type, int RoomID) : base(name, type, RoomID)
        {

        }

        #endregion


        #region METHODS



        #endregion
    }
}
