﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlavka_Clue_Game
{
    public class Player : Character
    {
        #region FIELDS

        private List<Item> _playersItems;
        private List<Clue> playersEvidence;

        #endregion

        public List<Item> PlayersItems
        {
            get { return _playersItems; }
            set { _playersItems = value; }
        }

        public List<Clue> PlayersEvidence
        {
            get { return playersEvidence; }
            set { playersEvidence = value; }
        }

        #region PROPERTIES



        #endregion


        #region CONSTRUCTORS

        public Player()
        {
            _playersItems = new List<Item>();
            playersEvidence = new List<Clue>();
        }

        public Player(string name, PlayerType type, int RoomID) : base(name, type, RoomID)
        {

        }

        #endregion


        #region METHODS



        #endregion
    }
}
