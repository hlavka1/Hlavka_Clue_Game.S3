﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlavka_Clue_Game
{
    /// <summary>
    /// define all Clue objects
    /// </summary>
    public class Clue : GameObject
    {
        public enum Type
        {
            Candlestick,
            Knife,
            Rope,
            LeadPipe,
            Revolver,
            Wrench,
            Poison
        }

        public override int GameObjectID { get; set; }

        public override string Name { get; set; }

        public Type ClueType { get; set; }

        public override string Description { get; set; }

        public override int RoomID { get; set; }

        public override bool HasValue { get; set; }

        public override int Value { get; set; }

        public override bool CanAddToInventory { get; set; }

    }
}
