﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hlavka_Clue_Game
{
    /// <summary>
    /// the Mansion class manages all of the game elements
    /// </summary>
    public class Mansion
    {
        private List<SexyFrenchMaids> SexyFrenchMaids;
        #region ***** define all lists to be maintained by the Mansion object *****

        //
        // list of all room s
        //
        public List<Room> Rooms { get; set; }

        //
        // list of all items
        //
        public List<Item> Items { get; set; }
       


        //
        // list of all Clue
        //
        public List<Clue> Clues { get; set; }

        #endregion

        #region ***** constructor *****

        //
        // default Mansion constructor
        //
        public Mansion()
        {
            //
            // instantiate the lists of room s and game objects
            //
            this.Rooms = new List<Room>();
            this.Items = new List<Item>();
            this.Clues = new List<Clue>();
            this.SexyFrenchMaids = new List<SexyFrenchMaids>();
            //
            // add all of the room s and game objects to their lists
            // 
            IntializeMansionRooms();
            IntializeMansionItems();
            IntializeMansionClues();
            IntializeMansionSexyFrenchMaids();
        }

        #endregion

        #region ***** define methods to get the next available ID for game elements *****

        /// <summary>
        /// return the next available ID for a Room object
        /// </summary>
        /// <returns>next RoomObjectID </returns>
        private int GetNextRoomID()
        {
            int MaxID = 0;

            foreach (Room Room in Rooms)
            {
                if (Room.RoomID > MaxID)
                {
                    MaxID = Room.RoomID;
                }
            }

            return MaxID + 1;
        }

        /// <summary>
        /// return the next available ID for an item
        /// </summary>
        /// <returns>next GameObjectID </returns>
        private int GetNextItemID()
        {
            int MaxID = 0;

            foreach (Item item in Items)
            {
                if (item.GameObjectID > MaxID)
                {
                    MaxID = item.GameObjectID;
                }
            }

            return MaxID + 1;
        }



        /// <summary>
        /// return the next available ID for a Clue
        /// </summary>
        /// <returns>next GameObjectID </returns>
        private int GetNextClueID()
        {
            int MaxID = 0;

            foreach (Clue Clue in Clues)
            {
                if (Clue.GameObjectID > MaxID)
                {
                    MaxID = Clue.GameObjectID;
                }
            }

            return MaxID + 1;
        }

        #endregion

        #region ***** define methods to return game element objects *****

        /// <summary>
        /// get a Room object using an ID
        /// </summary>
        /// <param name="ID">room  ID</param>
        /// <returns>requested room </returns>
        public Room GetRoomByID(int ID)
        {
            Room rmid = null;

            //
            // run through the room  list and grab the correct one
            //
            foreach (Room location in Rooms)
            {
                if (location.RoomID == ID)
                {
                    rmid = location;
                }
            }

            //
            // the specified ID was not found in the universe
            // throw and exception
            //
            if (rmid == null)
            {
                string feedbackMessage = $"The room ID {ID} does not exist in the current Mansion.";
                throw new ArgumentException(ID.ToString(), feedbackMessage);
            }

            return rmid;
        }

        /// <summary>
        /// get an item using an ID
        /// </summary>
        /// <param name="ID">game object ID</param>
        /// <returns>requested item object</returns>
        public Item GetItemtByID(int ID)
        {
            Item requestedItem = null;

            //
            // run through the item list and grab the correct one
            //
            foreach (Item item in Items)
            {
                if (item.GameObjectID == ID)
                {
                    requestedItem = item;
                }
            }

            //
            // the specified ID was not found in the universe
            // throw and exception
            //
            if (requestedItem == null)
            {
                string feedbackMessage = $"The item ID {ID} does not exist in the current Mansion.";
                throw new ArgumentException(ID.ToString(), feedbackMessage);
            }

            return requestedItem;
        }

        /// <summary>
        /// get a Clue using an ID
        /// </summary>
        /// <param name="ID">game object ID</param>
        /// <returns>requested Clue object</returns>
        public Clue GetClueByID(int ID)
        {
            Clue requestedClue = null;

            //
            // run through the item list and grab the correct one
            //
            foreach (Clue Clue in Clues)
            {
                if (Clue.GameObjectID == ID)
                {
                    requestedClue = Clue;
                };
            }

            //
            // the specified ID was not found in the universe
            // throw and exception
            //
            if (requestedClue == null)
            {
                string feedbackMessage = $"The Clue ID {ID} does not exist in the current Mansion.";
                throw new ArgumentException(ID.ToString(), feedbackMessage);
            }

            return requestedClue;
        }

        #endregion

        #region ***** define methods to get lists of game elements by location *****


        /// get a list of items using a room  ID
        /// </summary>
        /// <param name="ID">room  ID</param>
        /// <returns>list of items in the specified location</returns>
        public List<SexyFrenchMaids> GetSexyFrenchMaidsByRoomID(int ID)
        {
            // TODO validate RoomID
            List<SexyFrenchMaids> sexyFrenchMaidsInRoom = new List<SexyFrenchMaids>();

            //
            // run through the item list and put all items in the current location
            // into a list
            //
            foreach (SexyFrenchMaids sm in SexyFrenchMaids)
            {
                if (sm.RoomID == ID)
                {
                    sexyFrenchMaidsInRoom.Add(sm);
                }
            }

            return sexyFrenchMaidsInRoom;
        }

        /// get a list of Clues using a room  ID
        /// </summary>
        /// <param name="ID">room  ID</param>
        /// <returns>list of Clues in the specified location</returns>
        public List<Clue> GetCluesByRoomID(int ID)
        {
            // TODO validate RoomID
            List<Clue> CluesInRoom = new List<Clue>();

            //
            // run through the Clue list and put all items in the current location
            // into a list
            //
            foreach (Clue Clue in Clues)
            {
                if (Clue.RoomID == ID)
                {
                    CluesInRoom.Add(Clue);
                }
            }

            return CluesInRoom;
        }

        public List<Item> GetItemsByRoomID(int ID)
        {
            // TODO validate RoomID
            List<Item> ItemsInRoom = new List<Item>();

            //
            // run through the item list and put all items in the current location
            // into a list
            //
            foreach (Item Item in Items)
            {
                if (Item.RoomID == ID)
                {
                    ItemsInRoom.Add(Item);
                }
            }

            return ItemsInRoom;
        }

        #endregion

        #region ***** define methods to initialize all game elements *****

        /// <summary>
        /// initialize the universe with all of the room s
        /// </summary>
        private void IntializeMansionRooms()
        {
            Rooms.Add(new Room
            {
                Name = "Main Corridor",
                RoomID = 1,
                Description = "The main corridor is a large square with smaller jaunts off of its sides " +
                              "serve as passage between rooms.",
                Accessable = true
            });

            Rooms.Add(new Room
            {
                Name = "Study",
                RoomID = 2,
                Description = "In the study there is atrocious Lime Green carept with a couch that matches in the northwestern corner. " +
                              "There are 3 north facing windows and 2 west facing windows. On the south side of the room there is a desk. " +
                              "In the northeast corner of the room there is a small round table with a simple brass lamp. ." +
                "In the southwest corner of the room you see the carpet frayed, there is a hidden passage to the kitchen under the carpet! ",
                Accessable = true
            });

            Rooms.Add(new Room
            {
                Name = "Library",
                RoomID = 3,
                Description = "In the library there is gorgeous Birds Eye Maple Flooring. All of the bookshelves are made of the rare maple as well.  " +
                  "There is a long study table that spans almost the enitre length of the room.  There is a cozy reading nook on the west side of the library encompassed with windows.  " +
                  "The north side of the library has a fireplace framed into the bookshelves.  You look around the room and see hundreds of thousands of dollars worth of rare and first edition books.",
                Accessable = true
            });

            Rooms.Add(new Room
            {
                Name = "Billiard Room",
                RoomID = 4,
                Description = "In the billiard room there is a 9 foot billiard table with Royal blue felt and a rare black wood.  The table is already set up for a game of 9 ball.  " +
             "On the west side of the room the enitre wall is a large picture window over looking the fountain and the garden.  In the northeast corner of the room there is a corner bookshelf diplaying a flag and a dozen military medals.  " +
             "In the southeast corner there is a free standing pedistal lamp for asthetics, but the main light is the room comes from the window and the billards light oover the pool table.",
                Accessable = true
            });

            Rooms.Add(new Room
            {
                Name = "Conservatory",
                RoomID = 5,
                Description = "The conservatory is a room with a glass roof and walls, attached to the southwest corner of the house and used as a greenhouse.  " +
             "Looking aroudn the room at the plants you find yourself hoping that Mr. Boddy has his medical card.  There are also many vegetables and fruits.  " +
             "In the floor in the northwest corner of the room you notice scrapes, you push a planter out of the way and find a hidden passage to the lounge.",
                Accessable = true
            });

            Rooms.Add(new Room
            {
                Name = "Ballroom",
                RoomID = 6,
                Description = "In the ballroom the entire floor is dance floor made of Brazilian Cherry wood.  In the southeast corner of the room there is a white grand piano.  " +
             "On the north side of the room there are multiple couches with white flared woodwork as the arms and legs, they are upholstered with reddish leather that nearly matches the flooring.  " +
             "On the south side of the room in the middle there is a rounded alcove of windows over looking the grand round about driveway.",
                Accessable = true
            });

            Rooms.Add(new Room
            {
                Name = "Kitchen",
                RoomID = 7,
                Description = "In the kitchen the floor is 16 by 16 black and white marble tiles.  The counter tops and cabinets are nearly industrial looking being made of high grade stainless steel.  There are 2 windows on the east wall. " +
             "There is a 6' stainless steel island in the middle of the kitchen with a 5' gas stove with 8 burners, 4 on either side of a griddle nestled in the middle of it so that can cook from the north or south side of the island.  " +
             "Along the south side of the room there are twin glass door walk in coolers instead of refrigerators.  It appears the one is meant for food and the other for specialty craft beers from around the world.  The beer fridge has a lock on it, I hope you weren't thirsty.  You can see a Bells Two Hearted Ale through the glass, your mouth waters.  " +
             "In the southwest corner of the room you notice a loose tile, you find a hidden passage to the study.  ",

                Accessable = true
            });

            Rooms.Add(new Room
            {
                Name = "Dining Room",
                RoomID = 8,
                Description = "In the dining room there is a massive table that seats 20 people.  The table is already set, with all of the proper place settings.  The china looks irreplacable.  Over the table there is a 4 tiered crystal chandelier  " +
             "On the north and south side of the room there are 10' credenzas that appear antique. They are stocked with more rare china and glasswear.  " +
             "The east wall of the room is one big picture window that over looks that stable and the riding pasture.",
                Accessable = true
            });

            Rooms.Add(new Room
            {
                Name = "Lounge",
                RoomID = 9,
                Description = "In the lounge the floor and tables are a distinguished dark rich Mahogany.  There a supple dark brown leather sofas.  The room is dimmly lit from lights in the decorative insets in the walls.   " +
             "There are 3 stained glass windows on the east wall of the room.  On the end tables are are glass vases filled with water that is dyed red with lit floating red candles in each vase.  " +
             "In the southeast corner of the room you notice a creek in the floor. Additional inspection reveals a secret passage to the the Conservatory.",
                Accessable = true
            });

            Rooms.Add(new Room
            {
                Name = "Grand Entrance Hall",
                RoomID = 10,
                Description = "In the grand entrance hall the flooring appears to be one continuous cream colored marble slab.  On the walls there are pitures of Mr Boddy and his beloved Blood Hound.  " +
                            "On the north side of the entrance hall there is a arched 10' high door made of Acacia .  " +
                             "There are 2 benches 4' in length on the east and west sides of the room.",
                Accessable = true
            });
        }

        /// <summary>
        /// initialize the universe with all of the items
        /// </summary>
        private void IntializeMansionItems()
        {
            Items.Add(new Item
            {
                Name = "Key",
                GameObjectID = 1,
                Description = "A tiny gold key, looks like it might go to the lock in the kitchen.",
                RoomID = 9,
                HasValue = false,
                Value = 0,
                CanAddToInventory = true
            });

            Items.Add(new Item
            {
                Name = "Mirror",
                GameObjectID = 2,
                Description = "A full sized mirror with jewels decorating the border.",
                RoomID = 2,
                HasValue = false,
                Value = 0,
                CanAddToInventory = false
            });

            Items.Add(new Item
            {
                Name = "Magnifying Glass",
                GameObjectID = 3,
                Description = "The tool every good investigator needs.",
                RoomID = 0,
                HasValue = true,
                Value = 500,
                CanAddToInventory = true
            });

            Items.Add(new Item
            {
                Name = "Kitchen-Aid Stand Mixer",
                GameObjectID = 4,
                Description = "The mixer looks almost industrial, someone must really like to cook!",
                RoomID = 7,
                HasValue = false,
                Value = 500,
                CanAddToInventory = false
            });

        }


        private void IntializeMansionSexyFrenchMaids()
        {
            SexyFrenchMaids.Add(new SexyFrenchMaids
            {
                Name = "Margaux ",
                GameObjectID = 1,
                Description = "You see a gorgeous maid standing in he corner, 5' 6, blonde hair, green eyes staring straight at you.  She points her left index finger at you and gives you a come hither motion.",
                RoomID = 2,
                HasValue = false,
                Value = 0,
                CanAddToInventory = false
            });

            SexyFrenchMaids.Add(new SexyFrenchMaids
            {
                Name = "Marion  ",
                GameObjectID = 2,
                Description = "There is a sexy maid, 5' 2, jet black hair and blue eyes.  She is in the corner of the room agressively polishing the brass lamp. ",
                RoomID = 4,
                HasValue = false,
                Value = 0,
                CanAddToInventory = false
            });

            SexyFrenchMaids.Add(new SexyFrenchMaids
            {
                Name = "Maeva ",
                GameObjectID = 3,
                Description = "She is beautiful!  5' 5, burning red hair and green eyes.  Whe is in the middle of the ballroom floor dancing with the mop.",
                RoomID = 6,
                HasValue = false,
                Value = 0,
                CanAddToInventory = false
            });


        }

        /// <summary>
        /// initialize the universe with all of the Clues
        /// </summary>
        private void IntializeMansionClues()
        {
            Clues.Add(new Clue
            {
                Name = "Knife",
                ClueType = Clue.Type.Knife,
                GameObjectID = 1,
                Description = "The knife appears to be a Civil War relic but in pristine shape. Don't suppose the victim has a 7' deep cut?",
                RoomID = 2,
                HasValue = true,
                Value = 25,
                CanAddToInventory = true
            });

            Clues.Add(new Clue
            {
                Name = "Lead Pipe",
                ClueType = Clue.Type.LeadPipe,
                GameObjectID = 2,
                Description = "The pipe is approximately 3' in length and rusty at the ends. You could crack someones skull with this and cause tetanus.",
                RoomID = 3,
                HasValue = true,
                Value = 15,
                CanAddToInventory = true
            });

            Clues.Add(new Clue
            {
                Name = "Candlestick",
                ClueType = Clue.Type.LeadPipe,
                GameObjectID = 3,
                Description = "The candlestick is brass and approximatley 8 inches long, bet you could get a good swing at someone with this.",
                RoomID = 4,
                HasValue = true,
                Value = 10,
                CanAddToInventory = true
            });

            Clues.Add(new Clue
            {
                Name = "Rope",
                ClueType = Clue.Type.Rope,
                GameObjectID = 4,
                Description = "The rope appears to be a 6' section of paracord, perfect for strangling someone with.",
                RoomID = 6,
                HasValue = true,
                Value = 15,
                CanAddToInventory = true
            });

            Clues.Add(new Clue
            {
                Name = "Poison",
                ClueType = Clue.Type.Poison,
                GameObjectID = 5,
                Description = "The vile smells like bitter almonds.  Cyanide, FAST ACTING!",
                RoomID = 7,
                HasValue = true,
                Value = 15,
                CanAddToInventory = true
            });

            Clues.Add(new Clue
            {
                Name = "Revolver",
                ClueType = Clue.Type.Revolver,
                GameObjectID = 6,
                Description = "The revolver has a pearl pistol grip and snub nose barrel, this would be loud!",
                RoomID = 8,
                HasValue = true,
                Value = 15,
                CanAddToInventory = true
            });

            Clues.Add(new Clue
            {
                Name = "LeadPipe",
                ClueType = Clue.Type.Wrench,
                GameObjectID = 7,
                Description = "The wrench is a large pipe wrench about 10 inches long.  Swing batter, Swing!",
                RoomID = 9,
                HasValue = true,
                Value = 15,
                CanAddToInventory = true
            });

        }

   
        #endregion

    }
}

