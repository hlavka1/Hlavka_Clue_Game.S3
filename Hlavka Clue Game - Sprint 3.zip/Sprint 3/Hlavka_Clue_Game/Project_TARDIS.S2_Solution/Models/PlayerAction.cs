﻿namespace Hlavka_Clue_Game
{
    public enum PlayerAction
    {
        None,
        InvestigationSetup,
        LookAround,
        LookAt,
        PickUpItem,
        PickUpClue,
        PutDownItem,
        PutDownClue,
        Travel,
        PlayerInfo,
        PlayerInventory,
        PlayerClue,
        ListROOMDestinations,
        ListItems,
        ListClues,
        Exit
    }
}
